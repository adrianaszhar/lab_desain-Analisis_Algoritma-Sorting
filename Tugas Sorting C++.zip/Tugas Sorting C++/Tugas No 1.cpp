#include <iostream>
using namespace std;

 void Tampil(int b[], int z) {
	for(int a = 0; a < z; a++) {
			cout << b[a] << " ";
		}
}

	int main() {
	 int z;
	 int temp;
	
	cout << "Masukkan Array ";
	cin >> z;
	int b[z];
	
	for(int i = 0; i < z; i++) {
	cout << "Masukkan Angka - "<<i+1<<" : ";
		cin>>b[i];
		}
	cout << endl;
	for(int i = 0; i < z; i++) {
		for(int n = 0; n < z-1; n++) {
		if(b[n] > b[n+1]) {
		 temp = b[n];
		b[n] = b[n+1];
		b[n+1] = temp;
			}
		}
	  cout << endl;
	 cout << "Proses Sorting " << i+1 << endl;
	  Tampil(b, z);
	}
	
	 cout << endl;
	cout << endl;
	   cout << "Hasil Sorting : " << endl;
	Tampil(b,z);
	
	return 0; 
}
